﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace ciclos
{
    internal class Ejercicio9
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce un número entero para calcular su factorial:");
            int numero = Convert.ToInt32(Console.ReadLine());

            long factorial = 1;

            for (int i = 1; i <= numero; i++)
            {
                factorial *= i;
            }

            Console.WriteLine("El factorial de " + numero + " es: " + factorial);
        }
    }
}
*/