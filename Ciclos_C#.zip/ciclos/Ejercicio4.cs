﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace ciclos
{
    internal class Ejercicio4
    {
        static void Main(string[] args)
        {
            int suma = 0;
            int[] numeros = new int[10];

            Console.WriteLine("Introduce 10 numeros:");

            for (int i = 0; i < 10; i++)
            {
                numeros[i] = Convert.ToInt32(Console.ReadLine());
                suma += numeros[i];
            }

            double promedio = suma / 10.0;

            Console.WriteLine("La suma de los 10 numeros es: " + suma);
            Console.WriteLine("El promedio de los 10 numeros es: " + promedio);
        }
    }
}
*/