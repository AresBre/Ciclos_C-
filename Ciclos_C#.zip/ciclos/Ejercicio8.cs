﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace ciclos
{
    internal class Ejercicio8
    {
        static void Main(string[] args)
        {
            int numero = 1;
            int filas = 4;

            for (int i = 1; i <= filas; i++)
            {
                for (int j = 1; j <= filas - i; j++)
                {
                    Console.Write(" ");
                }
                for (int k = 1; k <= i; k++)
                {
                    Console.Write(numero + " ");
                    numero++;
                }
                Console.WriteLine();
            }
        }
    }
}
*/