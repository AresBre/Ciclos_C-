﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
namespace ciclos
{
    internal class Ejercicio5
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce un numero entero:");
            int numero = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Tabla de multiplicar del " + numero + ":");

            for (int i = 1; i <= 10; i++)
            {
                int resultado = numero * i;
                Console.WriteLine(numero + " x " + i + " = " + resultado + ".");
            }
        }
    }
}
*/