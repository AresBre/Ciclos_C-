﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace ciclos
{
    internal class Ejercicio3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce el numero de terminos de la serie de Fibonacci:");
            int n = Convert.ToInt32(Console.ReadLine());

            int a = 0, b = 1, suma = 0;

            Console.WriteLine("Serie de Fibonacci:");

            for (int i = 1; i <= n; i++)
            {
                Console.WriteLine(a);
                suma += a;
                int temp = a;
                a = b;
                b = temp + b;
            }

            Console.WriteLine("La suma de los primeros " + n + " terminos de la serie de Fibonacci es: "+ suma);

        }
    }
}
*/